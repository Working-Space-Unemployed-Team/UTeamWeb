import { Facebook, MessageCircle, Mail } from 'lucide-react'

export interface ContactChannel {
  id: string
  name: string
  icon: React.ReactNode
  url: string
  description: string
}

export const contactChannels: ContactChannel[] = [
  {
    id: 'facebook',
    name: 'Facebook',
    icon: 'Facebook',
    url: 'https://www.facebook.com/unemployedteam',
    description: 'Message us on Facebook for quick responses'
  },
  {
    id: 'zalo',
    name: 'Zalo',
    icon: 'MessageCircle',
    url: 'https://zalo.me/unemployedteam',
    description: 'Chat with us on Zalo for instant support'
  },
  {
    id: 'email',
    name: 'Email',
    icon: 'Mail',
    url: 'mailto:support@unemployedteam.com',
    description: 'Send us an email for detailed inquiries'
  }
]
