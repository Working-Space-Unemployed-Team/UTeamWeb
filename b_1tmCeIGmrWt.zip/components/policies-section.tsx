import { Shield, Eye } from 'lucide-react'

export function PoliciesSection() {
  return (
    <section id="policies" className="w-full py-16 sm:py-24 px-4 sm:px-6 lg:px-8 bg-card">
      <div className="max-w-7xl mx-auto">
        <div className="text-center space-y-4 mb-12">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-balance">
            Your Trust, Our Priority
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-balance">
            We are committed to protecting your data and maintaining transparent practices.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
          {/* Privacy Policy */}
          <div className="space-y-4">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center flex-shrink-0">
                <Eye className="w-6 h-6 text-accent" />
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-semibold">Privacy Policy</h3>
                <p className="text-muted-foreground leading-relaxed">
                  We respect your privacy and are transparent about how we collect, use, and protect your data. Your information is encrypted and never shared with third parties without your explicit consent.
                </p>
                <a
                  href="#"
                  className="inline-block text-accent hover:text-accent/80 font-medium transition-colors mt-2"
                >
                  Read Full Policy →
                </a>
              </div>
            </div>
          </div>

          {/* Terms of Service */}
          <div className="space-y-4">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center flex-shrink-0">
                <Shield className="w-6 h-6 text-accent" />
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-semibold">Terms of Service</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Our terms outline the rights and responsibilities of both UTeamWeb and our users. By using our platform, you agree to these terms and our commitment to providing a safe and secure service.
                </p>
                <a
                  href="#"
                  className="inline-block text-accent hover:text-accent/80 font-medium transition-colors mt-2"
                >
                  Read Full Terms →
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Additional Info */}
        <div className="mt-12 p-6 rounded-lg bg-background border border-border/50">
          <div className="text-center space-y-2">
            <p className="text-sm text-muted-foreground">
              <span className="font-semibold text-foreground">GDPR & CCPA Compliant</span> • Your data is protected under international privacy standards
            </p>
            <p className="text-sm text-muted-foreground">
              <span className="font-semibold text-foreground">SOC 2 Type II Certified</span> • We maintain the highest security and compliance standards
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
